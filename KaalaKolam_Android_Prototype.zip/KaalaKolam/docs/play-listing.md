# Play Console material (draft)

## App details
* Name: **Kaala Kolam** (Tamil title: காலக்கோலம்)
* Package: `edu.gascnagercoil.kaalakolam`
* Category: Education. Free. No ads. No in-app purchases.
* Target audience: all ages; not designed specifically for children (no data is collected from anyone).

## Short description (max 80 characters)
* EN: `Learn weather and climate from elders and science. Works fully offline.`
* TA (draft, please review): `வானிலை, காலநிலையைக் கற்க இணையமின்றி இயங்கும் இருமொழிச் செயலி.`

## Full description (English)
Kaala Kolam turns weather and climate into something you learn with your whole village.

* **Learn:** 24 topics, from clouds and monsoon to cyclones, heatwaves, floods, coral bleaching and climate change, each at three levels: little explorer, everyone, and deep dive.
* **Watch:** an animated, narrated clip for every topic, so children and adults can see how it works step by step.
* **Elders:** interview a grandparent about the changes they have seen, then compare their memories with instrument records.
* **Class:** pool interview codes with classmates, without any internet or account.
* **Council:** run a village adaptation council and see who gains and who is left exposed.
* **Predict:** make predictions and check how well calibrated you are.
* **Safety steps** for heat, floods, cyclones, lightning and the sea, in English and Tamil.

Fully bilingual (English and Tamil), works with no internet, collects no data, has no ads. Read-aloud uses your device's own voice (a Tamil voice must be installed for Tamil speech).

Created by R. Ramesh, Department of Zoology, GASC, Nagercoil. Educational use only; this is not an official warning service.

## Full description (Tamil, draft for language review)
காலக்கோலம் வானிலையையும் காலநிலை மாற்றத்தையும் முழு ஊருடன் சேர்ந்து கற்க உதவும் செயலி. 24 தலைப்புகள், ஒவ்வொன்றும் மூன்று நிலைகளில்; ஒவ்வொரு தலைப்புக்கும் அனிமேஷன் காட்சி; முதியோரிடம் நேர்காணல்; வகுப்பில் குறியீடுகளைப் பகிர்தல்; ஊர்ச் சபை விளையாட்டு; கணிப்புப் பயிற்சி; வெப்பம், வெள்ளம், புயல், மின்னல், கடல் எழுச்சி பற்றிய பாதுகாப்பு வழிகள். இணையம் தேவையில்லை; தகவல் சேகரிப்பு இல்லை; விளம்பரம் இல்லை. உருவாக்கம்: R. Ramesh, விலங்கியல் துறை, அரசு கலை மற்றும் அறிவியல் கல்லூரி, நாகர்கோவில். கல்விக்கு மட்டும்; அதிகாரப்பூர்வ எச்சரிக்கை சேவை அல்ல.

## Data safety form
* Does the app collect or share any user data types? **No.**
* Data encrypted in transit? Not applicable (no data leaves the device).
* Can users request data deletion? Not applicable (data is local; uninstalling removes it).
* Declare: no permissions, no ads, no third-party SDKs.

## Content rating notes
Educational. Includes factual safety information about floods, cyclones, heat, lightning and tsunami. No violence, no user-generated content shared between users.

## Screenshots to take (phone, portrait)
1. Home with the kolam. 2. Learn topic list. 3. A clip playing (monsoon or water cycle). 4. Elders interview results with testimony stripes. 5. Council scenario. 6. Tamil mode with the word list.

## Anticipating the "Minimum Functionality / repackaged website" question
This is not a website wrapper: all content ships inside the app and works offline; it has a native splash screen, adaptive and themed icons, a native About and credits screen, native share, Android TextToSpeech integration with a native prompt when a Tamil voice is missing, native Back-button handling, and an origin-locked WebView with no network permission. Cite this list if Play asks.

## Disclaimer to show in the listing
Educational use only. Not an official warning service. For weather warnings follow IMD and your State Disaster Management Authority. Check emergency numbers for your own district.
