# Device test checklist (tick on a real phone, then on an emulator with a different Android version)

Test on at least: one phone with Android 13 or later, and one older device near minSdk 24 if you have it.

| # | Check | Pass |
|---|---|---|
| 1 | Cold start: splash, then Home, no blank screen | |
| 2 | All six tabs open: Home, Learn, Elders, Class, Council, Predict | |
| 3 | Switch to Tamil: no empty boxes; the word list (தமிழ்–ஆங்கிலச் சொற்பட்டி) displays | |
| 4 | Learn, open a topic, press Watch: clip animates smoothly; Pause, Next, Replay, ½× work | |
| 5 | Leave the clip with Back: returns to the topic list and the clip stops | |
| 6 | Home, press Back: the app closes. Topic, Back, list, Back, Home | |
| 7 | Read aloud (English) and clip narration (English) speak | |
| 8 | Read aloud and narration in Tamil: speaks if a Tamil voice is installed; otherwise the native dialog appears once and the app does not crash | |
| 9 | Elders: record an interview. Swipe the app away from Recents, reopen: data still there | |
| 10 | Install a newer debug APK over the old one (`adb install -r`): data still there | |
| 11 | Class: paste a KK1. code and a KP1. code | |
| 12 | Rotate, change system font size, change system language, toggle system dark mode: no reload, no lost state, no sideways scrolling | |
| 13 | Menu: About and credits, Share, Text-to-speech settings, Privacy policy all work | |
| 14 | Airplane mode: everything works. `aapt dump permissions app-release.apk` lists no permissions | |
| 15 | Android 16 device or emulator: gesture back and three-button back both behave as in row 6 | |
| 16 | Tablet or foldable (about 600 dp wide or more): layout is usable, no letterboxing surprises | |
| 17 | Lint: Analyze > Inspect Code, then fix any errors | |

If row 7 or 8 is silent, open `chrome://inspect` on a desktop, inspect the WebView, and check the console for a CSP message about the injected script.
