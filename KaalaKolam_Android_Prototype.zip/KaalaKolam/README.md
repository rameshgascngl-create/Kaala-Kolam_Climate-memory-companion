# Kaala Kolam (காலக்கோலம்): Android prototype

Native Android shell around the unmodified offline HTML app
(`Kaala_Kolam_Climate_Memory_Companion.html`). Department of Zoology, GASC, Nagercoil / Created by R. Ramesh.

**Status: prototype precursor.** The project was written and checked for structure, XML, Kotlin syntax and
resource references, and the page-side code was tested in a desktop browser. It has **not** been compiled
or run on an Android device. The first Gradle sync and first device run are your first real test.

## What is in it

| Piece | Where | Purpose |
|---|---|---|
| The app itself | `app/src/main/assets/www/index.html` | Same file as the HTML app, plus one 8-line Back-button hook (see `docs/html-changes.diff`) |
| Loader | `MainActivity.kt` | WebViewAssetLoader at `https://appassets.androidplatform.net` (no `file://`), sandboxed WebView, edge-to-edge, Back handling, external links leave the app |
| Read-aloud fallback | `TtsBridge.kt` + `assets/tts_polyfill.js` | Android TextToSpeech behind `speechSynthesis`, origin-restricted; dialog if no Tamil voice |
| About and credits | `AboutActivity.kt` | Native screen: credit line, offline and privacy statement, disclaimer, share, privacy link |
| Icons | `res/drawable/ic_launcher_*.xml`, `res/mipmap-*` | Adaptive and monochrome kolam icon, legacy PNGs, `docs/playstore-icon-512.png` |
| Store material | `docs/` | Privacy policy page, listing text (EN/TA draft), data-safety answers, test checklist |

No permissions are requested. `allowBackup` is off. Cleartext traffic is off.

## Build

1. Install **Android Studio** (current stable) and, in SDK Manager, **Android SDK Platform 36**.
2. Open this folder. Let Gradle sync. If Studio offers the *Android Gradle Plugin Upgrade Assistant*, accept it:
   `libs.versions.toml` pins AGP 8.11.1, Kotlin 2.1.21, Gradle 8.13, which I could not resolve from my sandbox.
3. Run on an emulator or phone (**Run > app**). Debug builds use the id `edu.gascnagercoil.kaalakolam.debug`
   and enable `chrome://inspect` WebView debugging.
4. Command line: `./gradlew assembleDebug` (APK in `app/build/outputs/apk/debug/`).

Google Play requires **targetSdk 36** for new apps and updates from 31 August 2026. It is already set.

## Sign and release

```
keytool -genkeypair -v -keystore ~/keys/kaalakolam-release.jks -alias kaalakolam \
        -keyalg RSA -keysize 4096 -validity 10000
```
Put this in `~/.gradle/gradle.properties` (never in the repo):
```
KK_STORE_FILE=/home/you/keys/kaalakolam-release.jks
KK_STORE_PASSWORD=...
KK_KEY_ALIAS=kaalakolam
KK_KEY_PASSWORD=...
```
Then `./gradlew bundleRelease` gives `app/build/outputs/bundle/release/app-release.aab`.
Back up the keystore in two places. If you lose it you cannot update the app. Use Play App Signing when asked.

## Updating the content later

Replace `app/src/main/assets/www/index.html` with the new HTML, then re-add the hook block
(`window.__appBack`, see `docs/html-changes.diff`) just before `boot();`. Without it the Back button simply
closes the app. Bump `versionCode` and `versionName` in `app/build.gradle.kts`. Keep the origin and the
localStorage key unchanged so learners keep their data.

## Switches

* `SHOW_NATIVE_BAR` (in `app/build.gradle.kts`): `false` hides the thin native toolbar for a full-screen page.
  The overflow menu (About, Share, TTS settings, Privacy) then disappears with it.
* Privacy URL: `privacy_url` in `res/values/strings.xml` is a **guess** at where you will host
  `docs/privacy-policy.html` on GitHub Pages. Publish the page and correct the URL before submitting.

## Known limits and things I could not verify

* Not compiled. Library versions are unverified against Google Maven.
* The document-start script is assumed to bypass the page CSP the same way `evaluateJavascript` does. If
  `speechSynthesis` is not replaced on a device, check `chrome://inspect` for a CSP message.
* `onRenderProcessGone` recreates the activity; the page then reloads from localStorage.
* The hook gives one-level Back inside Learn and sends every other tab to Home. Back inside an Elders
  interview in progress goes to Home (the draft stays in localStorage).
* Tamil store text and the word list contain draft terms; have a Tamil language reviewer check them.
* Emergency numbers and scientific figures in the HTML still need the verification noted in the app.
