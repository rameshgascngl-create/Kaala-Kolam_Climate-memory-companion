package edu.gascnagercoil.kaalakolam

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.webkit.WebView
import androidx.webkit.JavaScriptReplyProxy
import androidx.webkit.WebMessageCompat
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import org.json.JSONObject
import java.util.Locale

/**
 * Gives the page a reliable speechSynthesis using Android's own TextToSpeech engine.
 *
 * - tts_polyfill.js (assets) is injected at document start, only for our own origin, and replaces
 *   window.speechSynthesis / SpeechSynthesisUtterance with thin wrappers.
 * - The wrappers talk to this class through a WebMessageListener restricted to ORIGIN, so no
 *   other site could ever call it (and no @JavascriptInterface is exposed).
 * - If the device has no Tamil voice, the page gets an "error" event and the user is offered the
 *   system text-to-speech settings (once per session).
 * If the installed WebView is too old for these features, nothing is injected and the page falls
 * back to the browser's own speechSynthesis (or its built-in "cannot read aloud" message).
 */
class TtsBridge(
    private val activity: Activity,
    private val webView: WebView,
    private val onTamilMissing: () -> Unit
) {
    private val main = Handler(Looper.getMainLooper())
    private var engine: TextToSpeech? = null
    private var ready = false
    private var queued: Runnable? = null
    private var queuedId: String? = null
    private var reply: JavaScriptReplyProxy? = null
    private var tamilWarned = false

    private val messageListener = WebViewCompat.WebMessageListener {
            _: WebView, message: WebMessageCompat, _, _: Boolean, proxy: JavaScriptReplyProxy ->
        reply = proxy
        val raw = message.data ?: return@WebMessageListener
        try {
            val o = JSONObject(raw)
            when (o.optString("op")) {
                "speak" -> speak(
                    o.optString("id"), o.optString("text"),
                    o.optString("lang", "en-IN"), o.optDouble("rate", 1.0).toFloat()
                )
                "stop" -> stop()
            }
        } catch (_: Exception) { /* ignore malformed messages */ }
    }

    private val utteranceListener = object : UtteranceProgressListener() {
        override fun onStart(utteranceId: String?) = emit(utteranceId, "start", null)
        override fun onDone(utteranceId: String?) = emit(utteranceId, "end", null)
        @Deprecated("Deprecated in Java")
        override fun onError(utteranceId: String?) = emit(utteranceId, "error", "synthesis-failed")
        override fun onError(utteranceId: String?, errorCode: Int) = emit(utteranceId, "error", "synthesis-failed")
        override fun onStop(utteranceId: String?, interrupted: Boolean) { /* cancel is initiated by the page: no event */ }
    }

    fun attach() {
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER) ||
            !WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)
        ) return
        val polyfill = activity.assets.open("tts_polyfill.js").bufferedReader().use { it.readText() }
        val origins = setOf(Constants.ORIGIN)
        WebViewCompat.addWebMessageListener(webView, "AndroidTTS", origins, messageListener)
        WebViewCompat.addDocumentStartJavaScript(webView, polyfill, origins)
    }

    private fun ensureEngine() {
        if (engine != null) return
        engine = TextToSpeech(activity.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ready = true
                engine?.setOnUtteranceProgressListener(utteranceListener)
                queued?.run()
            } else {
                ready = false
                emit(queuedId, "error", "engine-unavailable")
            }
            queued = null
            queuedId = null
        }
    }

    private fun speak(id: String, text: String, langTag: String, rate: Float) {
        ensureEngine()
        val job = Runnable { doSpeak(id, text, langTag, rate) }
        if (ready) job.run() else {
            queued = job
            queuedId = id
        }
    }

    private fun doSpeak(id: String, text: String, langTag: String, rate: Float) {
        val e = engine ?: return
        val result = e.setLanguage(Locale.forLanguageTag(langTag))
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            emit(id, "error", "language-unavailable")
            if (langTag.startsWith("ta") && !tamilWarned) {
                tamilWarned = true
                main.post { onTamilMissing() }
            }
            return
        }
        e.setSpeechRate(rate.coerceIn(0.5f, 2.0f))
        val limit = (TextToSpeech.getMaxSpeechInputLength() - 1).coerceAtLeast(100)
        e.speak(text.take(limit), TextToSpeech.QUEUE_FLUSH, Bundle(), id)
    }

    fun stop() {
        engine?.stop()
    }

    fun shutdown() {
        engine?.stop()
        engine?.shutdown()
        engine = null
        ready = false
    }

    private fun emit(id: String?, event: String, reason: String?) {
        if (id == null) return
        val payload = JSONObject().put("id", id).put("ev", event).put("reason", reason ?: "").toString()
        main.post { reply?.postMessage(payload) }
    }
}
