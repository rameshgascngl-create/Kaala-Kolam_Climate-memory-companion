package edu.gascnagercoil.kaalakolam

import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.webkit.ConsoleMessage
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewFeature
import com.google.android.material.appbar.MaterialToolbar

/**
 * Single-activity shell. The educational content is the unmodified offline HTML in assets/www.
 * Everything here is deliberately small: load the page from a fixed https origin, keep it
 * sandboxed, handle the Back button, and provide a native fallback for read-aloud.
 */
class MainActivity : AppCompatActivity() {

    private var webView: WebView? = null
    private var ttsBridge: TtsBridge? = null

    private val assetLoader: WebViewAssetLoader by lazy {
        WebViewAssetLoader.Builder()
            .setDomain(Constants.HOST)
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )
        setContentView(R.layout.activity_main)

        val root = findViewById<View>(R.id.root)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
            v.setPadding(bars.left, bars.top, bars.right, maxOf(bars.bottom, ime.bottom))
            WindowInsetsCompat.CONSUMED
        }

        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        if (BuildConfig.SHOW_NATIVE_BAR) {
            toolbar.inflateMenu(R.menu.main_menu)
            toolbar.setOnMenuItemClickListener { item ->
                when (item.itemId) {
                    R.id.action_about -> startActivity(Intent(this, AboutActivity::class.java))
                    R.id.action_share -> shareApp()
                    R.id.action_tts_settings -> openTtsSettings()
                    R.id.action_privacy -> openUrl(getString(R.string.privacy_url))
                    else -> return@setOnMenuItemClickListener false
                }
                true
            }
        } else {
            toolbar.visibility = View.GONE
        }

        val wv = findViewById<WebView>(R.id.webview)
        webView = wv
        setupWebView(wv)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val current = webView
                if (current == null) {
                    finish()
                    return
                }
                // The page decides whether it can step back (topic -> topic list -> Home).
                current.evaluateJavascript(
                    "(function(){try{return !!(window.__appBack&&window.__appBack())}catch(e){return false}})()"
                ) { handled ->
                    if (handled != "true") finish()
                }
            }
        })

        if (savedInstanceState == null || wv.url == null) {
            wv.loadUrl(Constants.START_URL)
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView(wv: WebView) {
        WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG)
        wv.setBackgroundColor(getColor(R.color.ground))
        with(wv.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true          // localStorage: learner progress, interviews, predictions
            allowFileAccess = false
            allowContentAccess = false
            setSupportMultipleWindows(false)
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            textZoom = 100                    // the page has its own "Aa" text-size control
            setGeolocationEnabled(false)
        }
        // The page has its own light/dark theme; do not let WebView darken it a second time.
        if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
            WebSettingsCompat.setAlgorithmicDarkeningAllowed(wv.settings, false)
        }

        ttsBridge = TtsBridge(this, wv) { showTamilVoiceMissingDialog() }.also { it.attach() }

        wv.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView, request: WebResourceRequest
            ): WebResourceResponse? = assetLoader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(
                view: WebView, request: WebResourceRequest
            ): Boolean {
                val uri = request.url
                if (uri.host == Constants.HOST) return false
                openUrl(uri.toString())      // anything external leaves the app sandbox
                return true
            }

            override fun onRenderProcessGone(
                view: WebView, detail: RenderProcessGoneDetail
            ): Boolean {
                (view.parent as? ViewGroup)?.removeView(view)
                view.destroy()
                webView = null
                runOnUiThread { recreate() }
                return true
            }
        }
        wv.webChromeClient = object : WebChromeClient() {
            override fun onConsoleMessage(m: ConsoleMessage): Boolean {
                if (BuildConfig.DEBUG) Log.d("KaalaKolamJS", "${m.messageLevel()}: ${m.message()} (${m.lineNumber()})")
                return true
            }
        }
    }

    // ---- native actions -------------------------------------------------------------------

    private fun openUrl(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addCategory(Intent.CATEGORY_BROWSABLE))
        } catch (_: ActivityNotFoundException) { /* no handler installed: ignore */ }
    }

    private fun shareApp() {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, getString(R.string.share_text))
        }
        startActivity(Intent.createChooser(send, getString(R.string.menu_share)))
    }

    private fun openTtsSettings() {
        try {
            startActivity(Intent("com.android.settings.TTS_SETTINGS"))
        } catch (_: ActivityNotFoundException) {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }

    private fun showTamilVoiceMissingDialog() {
        if (isFinishing || isDestroyed) return
        AlertDialog.Builder(this)
            .setTitle(R.string.tts_missing_title)
            .setMessage(R.string.tts_missing_message)
            .setPositiveButton(R.string.tts_open_settings) { _, _ -> openTtsSettings() }
            .setNegativeButton(R.string.close, null)
            .show()
    }

    // ---- lifecycle ------------------------------------------------------------------------

    override fun onPause() {
        webView?.onPause()      // stops page timers, so animation clips pause with the app
        ttsBridge?.stop()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        webView?.onResume()
    }

    override fun onDestroy() {
        ttsBridge?.shutdown()
        webView?.let {
            (it.parent as? ViewGroup)?.removeView(it)
            it.destroy()
        }
        webView = null
        super.onDestroy()
    }
}
