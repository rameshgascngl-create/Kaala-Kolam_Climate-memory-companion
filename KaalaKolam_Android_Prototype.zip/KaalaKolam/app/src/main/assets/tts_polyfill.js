/* Kaala Kolam: speechSynthesis backed by Android TextToSpeech.
   Injected at document start by TtsBridge, for the app origin only. Safe to run twice. */
(function () {
  'use strict';
  if (window.__kkTts || typeof AndroidTTS === 'undefined') return;
  window.__kkTts = true;

  var pending = {};
  var seq = 0;
  var speaking = false;
  var voices = [
    { name: 'Android voice (English, India)', lang: 'en-IN', localService: true, default: true, voiceURI: 'android-en-IN' },
    { name: 'Android voice (Tamil)', lang: 'ta-IN', localService: true, default: false, voiceURI: 'android-ta-IN' }
  ];

  function post(o) { try { AndroidTTS.postMessage(JSON.stringify(o)); } catch (e) { /* bridge missing */ } }

  AndroidTTS.onmessage = function (ev) {
    var m; try { m = JSON.parse(ev.data); } catch (e) { return; }
    var u = pending[m.id]; if (!u) return;
    if (m.ev === 'start') { speaking = true; if (u.onstart) u.onstart({ type: 'start' }); return; }
    speaking = false; delete pending[m.id];
    if (m.ev === 'end') { if (u.onend) u.onend({ type: 'end' }); }
    else if (u.onerror) { u.onerror({ type: 'error', error: m.reason || 'synthesis-failed' }); }
  };

  function Utterance(text) {
    this.text = text === undefined ? '' : String(text);
    this.lang = ''; this.voice = null; this.rate = 1; this.pitch = 1; this.volume = 1;
    this.onstart = null; this.onend = null; this.onerror = null;
  }

  var synth = {
    pending: false, paused: false, onvoiceschanged: null,
    getVoices: function () { return voices.slice(); },
    speak: function (u) {
      var id = 'u' + (++seq);
      pending[id] = u;
      post({ op: 'speak', id: id, text: u.text, lang: (u.voice && u.voice.lang) || u.lang || 'en-IN', rate: u.rate || 1 });
    },
    cancel: function () { pending = {}; speaking = false; post({ op: 'stop' }); },
    pause: function () {}, resume: function () {},
    addEventListener: function () {}, removeEventListener: function () {}
  };
  Object.defineProperty(synth, 'speaking', { get: function () { return speaking; } });

  Object.defineProperty(window, 'speechSynthesis', { value: synth, configurable: true });
  window.SpeechSynthesisUtterance = Utterance;
})();
