# The app has no reflection-based libraries. androidx.webkit ships its own consumer rules.
# Keep line numbers for readable crash reports in Play Console.
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
